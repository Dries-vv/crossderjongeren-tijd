<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
      <link rel="stylesheet" href="./styles/index.css" />
    <meta charset="utf-8">
    <title>Cross der jongeren ADMIN</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            padding: 2rem;
        }
        .form-label {
            font-weight: bold;
        }
        .form-control {
            border-radius: 8px;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
        .alert {
            border-radius: 8px;
        }
        #loperOverview {
            margin-top: 20px;
            width: 100%; /* Zorg ervoor dat het overzicht de volledige breedte gebruikt */
            overflow-x: auto; /* Voeg scroll toe voor horizontaal scrollen indien nodig */
        }
        .overview-table {
            width: 100%;
            min-width: 600px; /* Minimum breedte voor het overzicht, kun je aanpassen */
            border-collapse: collapse;
        }
        .overview-table th, .overview-table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
        .overview-table th {
            background-color: #f2f2f2;
        }
    </style>
</head>

<body>
    <?php include './header.php'; ?>

    <div class="container">
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <div class="card">
                    <h4 class="mb-4 text-primary text-center">Admin - Lopers Overzicht</h4>
                    <div class="mb-3">
                        <label for="reeksID" class="form-label">Reeks</label>
                        <select id="reeksID" class="form-control" onchange="toggleLopers()">
                            <option value="reeksID" disabled selected>Reeks</option>
                            <?php
                            $sql = "SELECT * FROM `reeksen` ORDER BY `reeks` DESC";
                            $statement = $conn->prepare($sql);
                            $results = $statement->execute();
                            $results = $statement->get_result();
                            while ($row = $results->fetch_assoc()) {
                                echo '<option value="' . $row['id'] . '">' . $row['reeks'] . '</option>';
                            }
                            ?>
                        </select>
                    </div>

                    <div id="loperOverview">
                        <table class="overview-table">
                            <thead>
                                <tr>
                                    <th>Naam</th>
                                    <th>School</th>
                                    <th>Klas</th>
                                    <th>Geslacht</th>
                                    <th>Geboortedatum</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
