  <?php
  session_start();
  ?>
  <!DOCTYPE html>
  <html lang="en" dir="ltr">

  <head>
    <title>Cross der jongeren</title>
    <link rel="stylesheet" href="./styles/index.css" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="./js/loperinsert.js"></script>

    <style>
      header {
  background-color: #2C3E50; /* Donkerblauw/grijs */
  padding: 15px 30px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
}

.logo-container {
  display: flex;
  align-items: center;
}

.logo {
  height: 50px; /* Logo grootte */
}

header ul {
  list-style: none;
  display: flex;
  gap: 20px;
  align-items: center;
  margin: 0;
  padding: 0;
}

header ul a {
  color: white;
  text-decoration: none;
  font-size: 18px;
  font-weight: 500;
  transition: color 0.3s ease-in-out;
}

header ul a:hover {
  color: #F39C12; /* Mooie gele hover */
}

.logout-button {
  background-color: #E74C3C;
  color: white;
  border: none;
  padding: 8px 15px;
  font-size: 16px;
  font-weight: bold;
  border-radius: 5px;
  cursor: pointer;
  transition: background 0.3s ease-in-out;
}

.logout-button:hover {
  background-color: #C0392B;
}

#login {
  display: flex;
  gap: 10px;
}

#login input {
  padding: 8px;
  border-radius: 5px;
  border: 1px solid #BDC3C7;
  font-size: 16px;
}

#loginButton {
  background-color: #3498DB;
  color: white;
  border: none;
  padding: 8px 15px;
  font-size: 16px;
  font-weight: bold;
  border-radius: 5px;
  cursor: pointer;
  transition: background 0.3s ease-in-out;
}

#loginButton:hover {
  background-color: #2980B9;
}

.alert {
  display: none;
  font-weight: bold;
  text-align: center;
  border-radius: 5px;
}

    </style>

  </head>


  <body>
    <?php
    include './header.php';
    ?>

    <div class="container">
      <div class="content">
        <div class="welcome-box">
          <h1>Welkom bij de cross der jongeren!</h1>
          <p>Om toegang te krijgen tot alle functies, moet je inloggen.</p>
        </div>
      </div>
    </div>
  </body>

  <style>
    .container {
      text-align: center;
      margin-top: 20px;
    }

    .welcome-box {
      background: white;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
      margin-top: 20px;
    }
  </style>

  </html>