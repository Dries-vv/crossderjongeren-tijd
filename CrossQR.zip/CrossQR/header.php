<?php
//session_start();
include './includes/dbh.inc.php';
?>

<link rel="stylesheet" href="./styles/index.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
<script defer src="https://use.fontawesome.com/releases/v5.0.8/js/all.js" integrity="sha384-SlE991lGASHoBfWbelyBPLsUlwY1GwNDJo3jSJO04KZ33K2bwfV9YBauFfnzvynJ" crossorigin="anonymous"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="./js/loperinsert.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/2.2.1/css/dataTables.dataTables.min.css">
<script src="https://cdn.datatables.net/2.2.1/js/dataTables.min.js"></script>

<?php
if ($_SESSION && $_SESSION['user']) {
  echo '<header>
        <div class="logo-container">
            <img src="./img/logo-provil.png" alt="Provil Logo" class="logo">
        </div>
        <ul>
          <a href="./update.php">Update</a>
          <a href="./lopers.php">Overzicht</a>
          <a href="./insert.php">Invoegen</a>
          <a href="./admin.php">Home</a>
          <button onclick="logout()" class="logout-button">Logout</button>
        </ul>
    </header>';
} else {
  echo '<header>
        <div class="logo-container">
            <img src="./img/logo-provil.png" alt="Provil Logo" class="logo">
        </div>
        <ul>
        <form id="login" action="" method="post">
        <input type="text" name="username" value="" placeholder="username">
        <input type="password" name="password" value="" placeholder="password">
        <input id="loginButton" type="submit" name="" value="login">
        </form>
        <div class="alert"></div>
        </ul>
    </header>';
}
?>

<script type="text/javascript">
  $('#login').on('submit', function(e) {
    e.preventDefault();
    $.ajax({
      url: "./includes/login.inc.php",
      method: "POST",
      data: new FormData(this),
      contentType: false,
      dataType: "json",
      processData: false,
      success: function(data) {
        if (data[0] == 'yes') {
          $('.alert').html('Je bent aangemeld');
          $('.alert').css({
            'background-color': '#69be6c',
            'padding': '20px'
          });
          $('.alert').slideDown("Slow");
          setTimeout(function() {
            $('.alert').slideUp("Slow");
            $('.alert').css({
              'padding': '0px'
            });
          }, 2000);
          setTimeout(function() {
            window.location.href = "./admin.php";
          }, 3000);
        } else {
          $('.alert').html(data[1]);
          $('.alert').css({
            'background-color': '#dd625d',
            'padding': '20px'
          });
          $('.alert').slideDown("Slow");
          setTimeout(function() {
            $('.alert').slideUp("Slow");
            $('.alert').css({
              'padding': '0px'
            });
          }, 2000);
        }
      }
    })
  });

  function logout() {
    $.ajax({
      url: './includes/logout.php',
      method: 'POST',
      data: {},
      dataType: 'json',
      success: function(data) {
        window.location.href = './index.php';
      }
    })
  }
</script>

<style>

</style>