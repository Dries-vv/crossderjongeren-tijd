<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="./styles/index.css" />
  <title>Cross der jongeren ADMIN</title>
</head>

<body>
  <?php
  include './header.php';
  ?>
  <div class="container" id="adminPage">
    <h1>Welcome <?php echo $_SESSION['user'] ?></h1>
  </div>
</body>

</html>