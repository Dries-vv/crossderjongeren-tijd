function insertLoper() {
    const firstname = $('#firstname').val();
    const lastname = $('#lastname').val();
    const gender = $('#gender').val();
    const birthdate = $('#birthdate').val();
    const schoolID = $('#schoolID').val();
    const klasID = $('#klasID').val();
    const reeksID = $('#reeksID').val();

    if (!firstname || !lastname || !gender || !birthdate || !schoolID || !reeksID) {
        $('#errorMessage').css({ 'display': 'block' })
        $('#errorMessage').html('Niet alle velden zijn ingevuld')

    } else {
        $.ajax({
            url: './includes/loperinsert.php',
            method: 'POST',
            data: {
                firstname,
                lastname,
                gender,
                birthdate,
                schoolID,
                klasID,
                reeksID
            },
            datatype: 'json',
            success: function () {
                console.log('yeah');
                $('#succesMessage').css({ 'display': 'block' })
                $('#succesMessage').html('Gebruiker toegevoegd')
                // setTimeout(function () {
                //     location.reload();  // Laadt de pagina opnieuw
                // }, 3000);
            }

        }
        )
    }
}
function insertKlas() {
    const klasName = $('#klasName').val();
    $.ajax({
        url: './includes/klas-insert.php',
        method: 'POST',
        data: {
            klasName
        },
        datatype: 'json',
        success: function () {
            console.log('yeah');
            $('#succesMessageKlas').css({ 'display': 'block' })
            $('#succesMessageKlas').html('Klas toegevoegd')
            setTimeout(function () {
               location.reload();
            }, 3000);
        }

    }
    )
}
function insertSchool() {
    const schoolName = $('#schoolName').val();
    $.ajax({
        url: './includes/school-insert.php',
        method: 'POST',
        data: {
            schoolName
        },
        datatype: 'json',
        success: function () {
            console.log('yeah');
            $('#succesMessageSchool').css({ 'display': 'block' })
            $('#succesMessageSchool').html('School toegevoegd')
            //setTimeout(function () {
            //    location.reload();
            //}, 3000);
        }

    }
    )
}

function toggleKlasVisibility() {
    const schoolID = $('#SchoolID').val();
    $('#klasContainer').hide();

    if (schoolID === "a4de7b6e-abee-11ef-a236-c84bd62df43c") {
        $('#klasContainer').show();
    } 
}


function toggleLopers() {
    const reeksID = $('#reeksID').val()
    console.log(reeksID);
    $.ajax({
        url: './includes/loper-get.php',
        method: 'POST',
        data: {
            reeksID
        },
        dataType: 'json',
        success: function (data) {
            console.log('yeah');
            console.log(data);
            $('#loperOverview').html(data[0])
            new DataTable('#example');
        }

    })
}


