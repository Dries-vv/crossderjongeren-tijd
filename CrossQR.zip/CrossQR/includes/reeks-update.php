<?php
include "./dbh.inc.php";
$response = array();


$reeksID = $_POST['reeksID'];
$nieuweReeks = $_POST['nieuweReeks'];
$sql = "UPDATE `reeksen` SET `reeks` = ? WHERE `id` = ?";
$statement = $conn->prepare($sql);
$statement->bind_param('ss', $nieuweReeks, $reeksID);
$statement->execute();

echo json_encode($response);

?>