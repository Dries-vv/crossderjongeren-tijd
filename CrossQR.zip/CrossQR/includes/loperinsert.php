    <?php 
    include "./dbh.inc.php";
    $response = array();


    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $gender = $_POST['gender'];
    $birthdate = $_POST['birthdate'];
    $schoolID = $_POST['schoolID'];
    $klasID = $_POST['klasID'];
    $reeksID = $_POST['reeksID'];



    $id = generateUUIDv4();
    $sql="INSERT INTO `lopers`(`id`, `firstname`, `lastname`, `gender`,`birthdate`,`schoolID`,`klasID`,`reeksID`) VALUES (?,?,?,?,?,?,?,?)";
    $statement = $conn->prepare($sql);
    $statement->bind_param('ssssssss', $id,$firstname,$lastname,$gender,$birthdate,$schoolID,$klasID,$reeksID);
    $statement->execute();


    echo json_encode($response);

    ?> 