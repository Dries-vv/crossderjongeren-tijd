<?php
include "./dbh.inc.php";

$firstname = $_GET['firstname'];
$userId = $_GET['id'];
$date = date('Y-m-d H:i:s');
$sql = "UPDATE `lopers` SET `finishTime` = ? WHERE `id` = ?";
$statement = $conn->prepare($sql);
$statement->bind_param('ss', $date, $userId);
$statement->execute();

if ($statement->execute()) {
    echo "✅ Finish tijd succesvol bijgewerkt voor loper ID: " . htmlspecialchars($firstname);
}
?>