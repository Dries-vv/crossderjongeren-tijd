<?php 
    include "./dbh.inc.php";
    $response = array();


    $name = $_POST['klasName'];
    $id = generateUUIDv4();
    $sql="INSERT INTO `klas`(`id`, `name`) VALUES (?,?)";
    $statement = $conn->prepare($sql);
    $statement->bind_param('ss', $id,$name);
    $statement->execute();


    echo json_encode($response);

    ?> 